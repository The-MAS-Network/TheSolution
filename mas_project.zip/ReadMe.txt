1. Implementation: This ia a full Django project on The Solution contest.

2. Libraries Used: Django, Python and Mysql

3. Security Measures: This website uses all of django's secure measures including password hashing and encryption, making it free from attacks liks cross site forgery,sql inection etc.

4. The fully responsive website link is at masnetwork.pythonanywhere.com

5. There are about 5 language options including English, Spanish, French, Italian and German. Ofcourse users can change the language to their preferred choice and it will be applied everywhere on the webapp.

6. See Live Link @  masnetwork.pythonanywhere.com

